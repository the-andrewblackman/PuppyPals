package net.revature;

//@WebMvcTest(AccountController.class)
public class AccountControllerTests {

//	@MockBean
//	private AccountService AccountService;

//	@Autowired
//	private MockMvc mockMvc;
//	
//	@Test
//	void accountCreationFailsWhenNameNotGiven() throws Exception {
//		mockMvc.perform((RequestBuilder) ((ResultActions) post("/account/new")
//				.contentType(MediaType.APPLICATION_JSON)
//				.content("{}"))
//				.andExpect(status().isBadRequest()));
//	}
//	
//	@Test
//	void accountFindUsernameFailsWhenNameNotGiven() throws Exception {
//		mockMvc.perform((RequestBuilder) ((ResultActions) post("/account/find/{username}")
//				.contentType(MediaType.APPLICATION_JSON)
//				.content("{}"))
//				.andExpect(status().isBadRequest()));
//	}
}
