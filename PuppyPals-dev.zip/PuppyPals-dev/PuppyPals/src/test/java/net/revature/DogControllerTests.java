package net.revature;

//@WebMvcTest(DogController.class)
public class DogControllerTests {
	
//	@MockBean
//	private AccountService AccountService;
//
//	@Autowired
//	private MockMvc mockMvc;
//	
//	@Test
//	void saveFailsWhenNoDog() throws Exception {
//		mockMvc.perform((RequestBuilder) ((ResultActions) post("/account/new")
//				.contentType(MediaType.APPLICATION_JSON)
//				.content("{}"))
//				.andExpect(status().isBadRequest()));
//	}

}
