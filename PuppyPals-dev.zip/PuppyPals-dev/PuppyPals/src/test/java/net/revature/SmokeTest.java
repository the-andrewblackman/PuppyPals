package net.revature;

//@SpringBootTest
public class SmokeTest {
	
//	@Autowired
//	private AccountController accountController;
//	
	// First test, sanity test, make sure tests work.
//	@Test
//	public void contextLoads() throws Exception {
//		assertThat(accountController).isNotNull();
//	}
}
