package net.revature;

//@SpringBootTest
//@AutoConfigureMockMvc
public class TestingWebApplicationTest {
	
//	@Autowired
//	private MockMvc mockMvc;
//	
//	@Test
//	public void shouldReturnDefaultMessage() throws Exception {
//		this.mockMvc.perform(get("/")).andDo(print()).andExpect(status().isOk())
//		.andExpect((ResultMatcher) content().string(containsString("Hello, World")));
//	}

}
